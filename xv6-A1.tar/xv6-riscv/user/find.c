#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fs.h"
#include "user/user.h"

static char *basename(char *path)
{
	char *name = path;

	for (char *p = path; *p; ++p) {
		if (*p == '/')
			name = p + 1;
	}
	return name;
}

static void find(char *path, char *target)
{
	char buffer[512];
	char *entry_path;
	int fd;
	struct dirent entry;
	struct stat file_stat;

	if ((fd = open(path, 0)) < 0) {
		fprintf(2, "find: cannot open %s\n", path);
		return;
	}
	if (fstat(fd, &file_stat) < 0) {
		fprintf(2, "find: cannot stat %s\n", path);
		close(fd);
		return;
	}

	if (file_stat.type == T_FILE) {
		if (strcmp(basename(path), target) == 0)
			printf("%s\n", path);
		close(fd);
		return;
	}
	if (file_stat.type != T_DIR) {
		close(fd);
		return;
	}

	if (strlen(path) + 1 + DIRSIZ + 1 > sizeof(buffer)) {
		fprintf(2, "find: path too long\n");
		close(fd);
		return;
	}
	strcpy(buffer, path);
	entry_path = buffer + strlen(buffer);
	*entry_path++ = '/';

	while (read(fd, &entry, sizeof(entry)) == sizeof(entry)) {
		if (entry.inum == 0 ||
			(entry.name[0] == '.' &&
			 (entry.name[1] == 0 || entry.name[1] == '.')))
			continue;
		memmove(entry_path, entry.name, DIRSIZ);
		entry_path[DIRSIZ] = 0;
		find(buffer, target);
	}
	close(fd);
}

int main(int argc, char *argv[])
{
	if (argc != 3) {
		fprintf(2, "usage: find path name\n");
		exit(1);
	}
	find(argv[1], argv[2]);
	exit(0);
}
