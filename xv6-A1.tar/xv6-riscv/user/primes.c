#include "kernel/types.h"
#include "user/user.h"

static void sieve(int input)
{
	int prime;
	int output[2];

	if (read(input, &prime, sizeof(prime)) != sizeof(prime)) {
		close(input);
		return;
	}
	printf("prime %d\n", prime);

	if (pipe(output) < 0) {
		fprintf(2, "primes: pipe failed\n");
		close(input);
		exit(1);
	}

	int child = fork();
	if (child < 0) {
		fprintf(2, "primes: fork failed\n");
		close(input);
		close(output[0]);
		close(output[1]);
		exit(1);
	}
	if (child == 0) {
		close(input);
		close(output[1]);
		sieve(output[0]);
		close(output[0]);
		exit(0);
	}

	close(output[0]);
	int value;
	while (read(input, &value, sizeof(value)) == sizeof(value)) {
		if (value % prime != 0)
			write(output[1], &value, sizeof(value));
	}
	close(input);
	close(output[1]);
	wait(0);
	exit(0);
}

int main(void)
{
	int channel[2];

	if (pipe(channel) < 0) {
		fprintf(2, "primes: pipe failed\n");
		exit(1);
	}
	int child = fork();
	if (child < 0) {
		fprintf(2, "primes: fork failed\n");
		exit(1);
	}
	if (child == 0) {
		close(channel[1]);
		sieve(channel[0]);
		close(channel[0]);
		exit(0);
	}

	close(channel[0]);
	for (int value = 2; value <= 35; ++value)
		write(channel[1], &value, sizeof(value));
	close(channel[1]);
	wait(0);
	exit(0);
}
