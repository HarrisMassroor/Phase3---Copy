#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[])
{
	int mask;

	if (argc < 3) {
		fprintf(2, "usage: trace mask command [args ...]\n");
		exit(1);
	}
	mask = atoi(argv[1]);
	if (trace(mask) < 0) {
		fprintf(2, "trace: unable to set mask\n");
		exit(1);
	}
	if (exec(argv[2], &argv[2]) < 0) {
		fprintf(2, "trace: exec %s failed\n", argv[2]);
		exit(1);
	}
	exit(0);
}
